#ifndef PINGUINO_H
#define PINGUINO_H
#include "Ave.h"

// El pinguino es un Ave pero no es AveVolador
// 
class Pinguino : public Ave {
public:
	string getNombre();
};

#endif
