#ifndef AVE_H
#define AVE_H
#include <iostream>
using namespace std;

// Todas las aves saben comer
class Ave {
public:
	virtual ~Ave();
	virtual string getNombre() = 0;
	void comer();
};

#endif
