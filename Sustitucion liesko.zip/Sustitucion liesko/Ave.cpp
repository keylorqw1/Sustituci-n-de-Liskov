#include "Ave.h"

Ave::~Ave() {}

void Ave::comer() {
	cout << getNombre() << " esta comiendo" << endl;
}
