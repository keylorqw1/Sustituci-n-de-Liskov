#include <iostream>
#include "Gorrion.h"
#include "Pinguino.h"
using namespace std;

// Funciona con cualquier Ave
void alimentar(Ave &ave) {
	ave.comer();
}

int main() {
	Gorrion gorrion;
	Pinguino pinguino;
	
	alimentar(gorrion);
	alimentar(pinguino);
	
	gorrion.volar();
	
	return 0;
}
