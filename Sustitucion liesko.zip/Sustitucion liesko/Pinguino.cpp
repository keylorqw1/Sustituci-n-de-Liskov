#include "Pinguino.h"

string Pinguino::getNombre() {
	return "El pinguino";
}
