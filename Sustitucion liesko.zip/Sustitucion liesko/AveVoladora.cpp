#include "AveVoladora.h"

void AveVoladora::volar() {
	cout << getNombre() << " esta volandop" << endl;
}
