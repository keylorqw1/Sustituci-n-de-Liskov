#ifndef AVEVOLADORA_H
#define AVEVOLADORA_H
#include "Ave.h"

// Solo las aves que vuelan saben volar
class AveVoladora : public Ave {
public:
	void volar();
};

#endif
