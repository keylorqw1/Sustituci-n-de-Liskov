#ifndef GORRION_H
#define GORRION_H
#include "AveVoladora.h"

class Gorrion : public AveVoladora {
public:
	string getNombre();
};

#endif
