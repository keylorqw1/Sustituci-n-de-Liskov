#include "Gorrion.h"

string Gorrion::getNombre() {
	return "El gorrion";
}
